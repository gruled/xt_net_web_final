﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

    public class KeyboardInput : IInput
    {
        //[Inject(ContextKeys.CONTEXT_DISPATCHER)]
        //public IEventDispatcher dispatcher { get; set; }

        [Inject]
        public IRoutineRunner routinerunner { get; set; }

        [Inject]
        public GameInputSignal gameInputSignal { get; set; }

        [PostConstruct]
        public void PostConstruct()
        {
            routinerunner.StartCoroutine(update());
        }

        private bool firing = false;

        protected IEnumerator update()
        {
            while (true)
            {
                int input = GameInputEvent.NONE;
               
                if (Input.GetKey(KeyCode.LeftArrow))
                {
                    input |= GameInputEvent.ROTATE_LEFT;
                }

                if (Input.GetKey(KeyCode.RightArrow))
                {
                    input |= GameInputEvent.ROTATE_RIGHT;
                }
                gameInputSignal.Dispatch(input);
                yield return null;
            }
        }
    }
