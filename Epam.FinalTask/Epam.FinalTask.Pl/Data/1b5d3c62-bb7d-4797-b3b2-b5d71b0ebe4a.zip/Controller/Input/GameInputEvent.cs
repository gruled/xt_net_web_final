﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameInputEvent  {

    public static int NONE = 0;
    public static int ROTATE_LEFT = 90;
    public static int ROTATE_RIGHT = -90;
}
