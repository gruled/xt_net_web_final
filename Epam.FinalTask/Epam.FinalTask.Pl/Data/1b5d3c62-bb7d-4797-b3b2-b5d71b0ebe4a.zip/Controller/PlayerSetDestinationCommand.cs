﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using strange.extensions.command.impl;
using strange.extensions.pool.api;

public class PlayerSetDestinationCommand : Command
{

    [Inject]
    public int rotation { get; set; }

    [Inject]
    public RotatePlayerSignal RotatePlayerSignal { get; set; }

    public override void Execute()
    {
                Debug.Log("RotateExec");
        RotatePlayerSignal.Dispatch(90f);
    }
}